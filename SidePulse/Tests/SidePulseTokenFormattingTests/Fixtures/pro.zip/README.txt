SidePulse Pro firmware update - version 1.1.0
